//
//  CustomPointAnnotation.swift
//  places
//
//  Created by Ashish Verma on 11/8/17.
//  Copyright © 2017 Ashish Verma. All rights reserved.
//

//import UIKit
//import MapKit
//
//class CustomPointAnnotation: MKPointAnnotation {
//    var pinCustomImageName:String!
//}

