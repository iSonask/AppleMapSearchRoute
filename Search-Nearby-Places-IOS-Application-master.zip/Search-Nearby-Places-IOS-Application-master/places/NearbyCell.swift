//
//  nearbyCell.swift
//  places
//
//  Created by Ashish Verma on 11/8/17.
//  Copyright © 2017 Ashish Verma. All rights reserved.
//

import UIKit
import MapKit

class NearbyCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()

    }

    func updateUI(responseResult: MKMapItem) {
       // cellTitle
    }

}

